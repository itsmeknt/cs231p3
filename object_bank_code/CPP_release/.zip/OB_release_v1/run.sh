rm ./outputs/*
make clean && make
./OBmain ./inputs/ ./outputs/
