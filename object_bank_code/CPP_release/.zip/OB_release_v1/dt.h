#pragma once
#include "mymex.h"
#define IN
#define OUT

using namespace std;
void dt(IN const mxArray * mxMatch, IN double ax, IN double bx, IN double ay, IN double by, OUT mxArray * & mxM); 

