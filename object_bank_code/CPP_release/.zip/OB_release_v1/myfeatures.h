#pragma once
#include "mymex.h"

mxArray *features(const mxArray *mximage, const mxArray *mxsbin); 
