#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void MaxGetSpatialPyramid(float responseMap[], int nLevel, float feature[], int height, int width);
