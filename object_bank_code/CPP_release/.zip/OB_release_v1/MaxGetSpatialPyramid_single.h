#include<vector>
#include<iostream>

void MaxGetSpatialPyramid_single(float responseMap[], int nGrid, float feature[], int start, int height, int width);
double getMaxCurrGrid(float responseMap[], int xStart, int xEnd, int yStart, int yEnd, int width);
