clear;
addpath(genpath({}));
load({});

av = mean(trainf,1);
sig = std(trainf,1);
for row = 1:size(trainf,1), trainf(row,:) = (trainf(row,:) - av)./sig; end
for row = 1:size(testf,1), testf(row,:) = (testf(row,:) - av)./sig; end
trainf = trainf/1000; testf = testf/1000;

model=train(double(trainl'), sparse(trainf), '-s 0 -c 1e7 -B 0');
[pred, acc, p] = predict(double(testl'), sparse(testf), model, '-b 1');
